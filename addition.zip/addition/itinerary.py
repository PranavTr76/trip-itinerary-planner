import pandas as pd
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
import re
from models import Itinerary
from database import db
from datetime import datetime
import io
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

itinerary_bp = Blueprint('itinerary', __name__)

# Load the CSV data
data = pd.read_csv("data/Filtered_output.csv")

def clean_text(text):
    # Basic cleaning: strip, replace multiple spaces, fix common punctuation spacing
    text = text.strip()
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'\s([?.!"](?:\s|$))', r'\1', text)
    return text

def generate_placeholder(day_num, city):
    return f"Day {day_num} itinerary for {city} is not available. Please explore local attractions and enjoy your day!"

def split_itinerary(itinerary_text, city):
    days = []
    # Use regex to split by "Day X:" labels
    pattern = re.compile(r'(Day \d+:)')
    parts = pattern.split(itinerary_text)
    # parts will be like ['', 'Day 1:', ' text1 ', 'Day 2:', ' text2 ', ...]
    day_texts = []
    for i in range(1, len(parts), 2):
        day_label = parts[i]
        day_content = parts[i+1] if i+1 < len(parts) else ''
        full_text = day_label + day_content
        day_texts.append(full_text)
    # Clean each day's text by removing the day label and cleaning text
    for i, day_text in enumerate(day_texts):
        # Remove the day label
        day_content = re.sub(r'Day \d+:', '', day_text).strip()
        day_content = clean_text(day_content)
        if not day_content:
            day_content = generate_placeholder(i+1, city)
        days.append(day_content)
    # If no days found, fallback to splitting into 4 parts
    if not days:
        length = len(itinerary_text)
        part_len = length // 4
        for i in range(4):
            start = i * part_len
            end = (i + 1) * part_len if i < 3 else length
            day_text = itinerary_text[start:end].strip()
            day_text = clean_text(day_text)
            if not day_text:
                day_text = generate_placeholder(i+1, city)
            days.append(day_text)
    return days

@itinerary_bp.route('/dashboard', methods=['GET'])
def dashboard():
    return render_template('dashboard.html')

@itinerary_bp.route('/accommodation/<city>', methods=['GET'])
def accommodation(city):
    # Filter accommodations based on the city
    accommodations = data[data['City'] == city].head(5)  # Get first 5 accommodations
    return render_template('accommodation.html', accommodations=accommodations)

from flask_login import login_required

@itinerary_bp.route('/search', methods=['GET', 'POST'])
@login_required
def search():
    results = []
    itinerary_days = []
    city = ""
    if request.method == 'POST':
        city = request.form.get('city')
        if city:
            city = city.strip()
        # Filter results based on the city input and get top 4 unique places
        filtered_data = data[data['City'].str.contains(city, case=False)]
        filtered_data = filtered_data.drop_duplicates(subset=['Place']).head(4)
        results = filtered_data

        # Check if edited itinerary exists in DB
        itinerary_entry = Itinerary.query.filter_by(city=city).first()
        if itinerary_entry:
            itinerary_text = itinerary_entry.itinerary_text
        else:
            # Extract itinerary text by concatenating itineraries of the places
            itinerary_text = " ".join(filtered_data['Itinerary'].tolist())

        itinerary_days = split_itinerary(itinerary_text, city)

    # Fetch all itineraries for the current user to pass to template
    all_itineraries = Itinerary.query.order_by(Itinerary.city).all()

    return render_template('results.html', results=results, itinerary_days=itinerary_days, city=city, itineraries=all_itineraries)

@itinerary_bp.route('/itinerary/download/<city>', methods=['GET'])
def download_itinerary(city):
    city = city.strip()
    itinerary_entry = Itinerary.query.filter_by(city=city).first()
    if itinerary_entry:
        itinerary_text = itinerary_entry.itinerary_text
    else:
        filtered_data = data[data['City'].str.contains(city, case=False)]
        filtered_data = filtered_data.drop_duplicates(subset=['Place']).head(4)
        itinerary_text = " ".join(filtered_data['Itinerary'].tolist())
    itinerary_days = split_itinerary(itinerary_text, city)

    # Create PDF in memory
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    y = height - 50
    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, y, f"Itinerary for {city}")
    y -= 40
    p.setFont("Helvetica", 12)
    for i, day_text in enumerate(itinerary_days, start=1):
        text = f"Day {i}: {day_text}"
        for line in text.split('\n'):
            p.drawString(50, y, line)
            y -= 15
            if y < 50:
                p.showPage()
                y = height - 50
                p.setFont("Helvetica", 12)
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"{city}_itinerary.pdf", mimetype='application/pdf')

@itinerary_bp.route('/itinerary/edit/<city>', methods=['GET', 'POST'])
def edit_itinerary(city):
    city = city.strip()
    itinerary_entry = Itinerary.query.filter_by(city=city).first()
    if request.method == 'POST':
        # Collect edited days from form
        days = []
        for key in sorted(request.form.keys()):
            if key.startswith('day_'):
                days.append(request.form.get(key))
        # Join days into single itinerary text with "Day X:" labels
        itinerary_text = ""
        for i, day_text in enumerate(days, start=1):
            itinerary_text += f"Day {i}: {day_text}\n"
        if itinerary_entry:
            itinerary_entry.itinerary_text = itinerary_text
            itinerary_entry.timestamp = datetime.utcnow()
        else:
            itinerary_entry = Itinerary(city=city, itinerary_text=itinerary_text)
            db.session.add(itinerary_entry)
        db.session.commit()
        flash('Itinerary updated successfully!', 'success')
        return redirect(url_for('itinerary.search'))
    else:
        if itinerary_entry:
            itinerary_text = itinerary_entry.itinerary_text
        else:
            # Load from CSV if no edited itinerary
            filtered_data = data[data['City'].str.contains(city, case=False)]
            filtered_data = filtered_data.drop_duplicates(subset=['Place']).head(4)
            itinerary_text = " ".join(filtered_data['Itinerary'].tolist())
        itinerary_days = split_itinerary(itinerary_text, city)
        return render_template('edit_itinerary.html', city=city, itinerary_days=itinerary_days)

from flask_login import login_required

@itinerary_bp.route('/itinerary/delete/<city>', methods=['POST'])
@login_required
def delete_itinerary(city):
    city = city.strip()
    itinerary_entry = Itinerary.query.filter_by(city=city).first()
    if itinerary_entry:
        db.session.delete(itinerary_entry)
        db.session.commit()
        flash(f'Itinerary for {city} deleted successfully.', 'success')
    else:
        flash(f'No itinerary found for {city}.', 'warning')
    return redirect(url_for('itinerary.search'))

@itinerary_bp.route('/itinerary/create', methods=['GET', 'POST'])
@login_required
def create_itinerary():
    if request.method == 'POST':
        city = request.form.get('city', '').strip()
        if not city:
            flash('City name is required.', 'warning')
            return redirect(url_for('itinerary.create_itinerary'))

        # Collect day-wise itinerary details
        days = []
        for key in sorted(request.form.keys()):
            if key.startswith('day_'):
                day_text = request.form.get(key).strip()
                if day_text:
                    days.append(day_text)

        if not days:
            flash('Please provide itinerary details for at least one day.', 'warning')
            return redirect(url_for('itinerary.create_itinerary'))

        # Join days into itinerary text with "Day X:" labels
        itinerary_text = ""
        for i, day_text in enumerate(days, start=1):
            itinerary_text += f"Day {i}: {day_text}\n"

        # Check if itinerary for city already exists
        itinerary_entry = Itinerary.query.filter_by(city=city).first()
        if itinerary_entry:
            flash(f'Itinerary for {city} already exists. You can edit it instead.', 'warning')
            return redirect(url_for('itinerary.edit_itinerary', city=city))

        # Create new itinerary entry
        new_itinerary = Itinerary(city=city, itinerary_text=itinerary_text)
        db.session.add(new_itinerary)
        db.session.commit()
        flash(f'Itinerary for {city} created successfully!', 'success')
        return redirect(url_for('itinerary.search'))

    return render_template('create_itinerary.html')
