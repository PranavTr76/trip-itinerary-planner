import pandas as pd

def generate_days_3_4(city):
    """Generate customized day 3-4 itinerary based on city name"""
    city = city.lower()
    
    # Customize days 3-4 based on city type
    if 'hill' in city or 'mountain' in city:
        day3 = "Day 3: Trekking and nature walks"
        day4 = "Day 4: Relax at scenic viewpoints"
    elif 'beach' in city or 'coast' in city:
        day3 = "Day 3: Water sports and beach activities" 
        day4 = "Day 4: Sunset cruise and seafood dinner"
    elif 'historic' in city or 'fort' in city:
        day3 = "Day 3: Heritage walks and museum visits"
        day4 = "Day 4: Cultural performances"
    else:
        day3 = "Day 3: Local experiences and workshops"
        day4 = "Day 4: Leisure time and shopping"
    
    return f"{day3}; {day4}"

# Read CSV
df = pd.read_csv('D:/VS Practice/project 2/dataset/Filtered_output.csv')

# Update itineraries
for index, row in df.iterrows():
    if pd.notna(row['Itinerary']):
        # Get existing day 1-2
        days = row['Itinerary'].split(';')[:2]
        # Generate new day 3-4
        days.extend(generate_days_3_4(row['City']).split(';'))
        # Update itinerary
        df.at[index, 'Itinerary'] = '; '.join(days)
    else:
        # If no existing itinerary, generate full 4-day
        df.at[index, 'Itinerary'] = generate_days_3_4(row['City'])

# Save back to CSV
df.to_csv('D:/VS Practice/project 2/dataset/Filtered_output.csv', index=False)

print("Successfully updated itineraries for all cities")
