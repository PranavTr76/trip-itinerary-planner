from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField, FileField
from wtforms.validators import DataRequired, Length

class BlogPostForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired(), Length(max=200)])
    content = TextAreaField('Content', validators=[DataRequired()])
    submit = SubmitField('Submit')

class PhotoUploadForm(FlaskForm):
    photo = FileField('Upload Photo', validators=[DataRequired()])
    submit = SubmitField('Upload')
