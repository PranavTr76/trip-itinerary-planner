from flask import Flask, redirect, url_for, session, render_template, request, flash
from flask_login import LoginManager, current_user, login_required
from auth import bp as auth_bp
from itinerary import itinerary_bp
from forms import BlogPostForm, PhotoUploadForm
from models import BlogPost, User
from database import db
from flask_migrate import Migrate
import os
from werkzeug.utils import secure_filename
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Add OpenWeatherMap API key configuration
app.config['OPENWEATHERMAP_API_KEY'] = 'AIzaSyD7yIA2yIOmdHwcHRh7s4oUEV8X445XYik'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
migrate = Migrate(app, db)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'

app.register_blueprint(auth_bp)
app.register_blueprint(itinerary_bp)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def home():
    return redirect(url_for('auth.login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/select')
@login_required
def select():
    return render_template('select.html')

@app.route('/blog/list')
@login_required
def blog_list():
    user_id = current_user.id
    blogs = BlogPost.query.filter_by(user_id=user_id).order_by(BlogPost.timestamp.desc()).all()
    # Deserialize photos JSON string to list for each blog
    for blog in blogs:
        if blog.photos:
            blog.photos = json.loads(blog.photos)
        else:
            blog.photos = []
    return render_template('blog_list.html', blogs=blogs)

@app.route('/blog/<int:blog_id>/delete', methods=['POST'])
@login_required
def delete_blog(blog_id):
    blog_post = BlogPost.query.get_or_404(blog_id)
    if blog_post.user_id != current_user.id:
        flash('You do not have permission to delete this blog.')
        return redirect(url_for('blog_list'))
    db.session.delete(blog_post)
    db.session.commit()
    flash('Blog deleted successfully.')
    return redirect(url_for('blog_list'))

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/blog/<int:blog_id>/upload_photo', methods=['GET', 'POST'])
@login_required
def upload_photo(blog_id):
    blog_post = BlogPost.query.get_or_404(blog_id)
    if blog_post.user_id != current_user.id:
        flash('You do not have permission to upload photos for this blog.')
        return redirect(url_for('blog_list'))
    form = PhotoUploadForm()
    if form.validate_on_submit():
        file = form.photo.data
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            # Update blog post photos field
            photos = []
            if blog_post.photos:
                photos = json.loads(blog_post.photos)
            photos.append(filename)
            blog_post.photos = json.dumps(photos)
            db.session.commit()
            flash('Photo uploaded successfully.')
            return redirect(url_for('blog_list'))
        else:
            flash('Invalid file type.')
    return render_template('upload_photo.html', form=form, blog=blog_post)

@app.route('/blog/write', methods=['GET', 'POST'])
@login_required
def blog_write():
    form = BlogPostForm()
    if form.validate_on_submit():
        user_id = current_user.id
        title = form.title.data
        content = form.content.data
        blog_post = BlogPost(user_id=user_id, title=title, content=content)
        db.session.add(blog_post)
        db.session.commit()
        return redirect(url_for('upload_photo', blog_id=blog_post.id))
    return render_template('blog_write.html', form=form)

@app.route('/blog/<int:blog_id>')
@login_required
def view_blog(blog_id):
    blog_post = BlogPost.query.get_or_404(blog_id)
    if blog_post.user_id != current_user.id:
        flash('You do not have permission to view this blog.')
        return redirect(url_for('blog_list'))
    photos = []
    if blog_post.photos:
        photos = json.loads(blog_post.photos)
    return render_template('blog_view.html', blog=blog_post, photos=photos)

@app.route('/blog/<int:blog_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_blog(blog_id):
    blog_post = BlogPost.query.get_or_404(blog_id)
    if blog_post.user_id != current_user.id:
        flash('You do not have permission to edit this blog.')
        return redirect(url_for('blog_list'))
    form = BlogPostForm(obj=blog_post)
    if form.validate_on_submit():
        blog_post.title = form.title.data
        blog_post.content = form.content.data
        db.session.commit()
        flash('Blog updated successfully.')
        return redirect(url_for('blog_list'))
    return render_template('blog_write.html', form=form, edit=True)

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
